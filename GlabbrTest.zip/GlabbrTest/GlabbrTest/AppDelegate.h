//
//  AppDelegate.h
//  GlabbrTest
//
//  Created by Apple on 11/4/17.
//  Copyright © 2017 chiselcut. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

